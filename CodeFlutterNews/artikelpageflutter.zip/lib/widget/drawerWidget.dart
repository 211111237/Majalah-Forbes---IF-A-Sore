import 'package:flutter/material.dart';

class drawerWidget extends StatelessWidget {
  const drawerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Image.asset(
                  "../../lib/assets/images/logo.png",
                  width: 180,
                ),
              ],
            ),
          ),
          ListTile(
            title: Text("Megumin Exc"),
            subtitle: Text("EmailDavid@gmail.com"),
            leading: Container(
              height: 80,
              child: CircleAvatar(
                backgroundImage:
                    AssetImage("../../lib/assets/images/person2.png"),
              ),
            ),
          ),
          Divider(
            height: 1,
            thickness: 1,
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Setting"),
            // selected: _selectedDestination == false,
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.topic),
            title: Text("Topik"),
            // selected: _selectedDestination == false,
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text("Logout"),
            // selected: _selectedDestination == false,
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
