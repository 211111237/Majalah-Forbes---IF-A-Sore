import 'package:flutter/material.dart';
import '../screen/login_page.dart';

class register_page extends StatefulWidget {
  const register_page({super.key});

  @override
  State<register_page> createState() => _register_pageState();
}

class _register_pageState extends State<register_page> {
  String? gender;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "register",
      home: Scaffold(
        appBar: AppBar(
          title: Image.asset(
            "lib/assets/images/logo.png",
            width: 80,
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.only(right: 20, left: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Sign Up Your Account",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Regular',
                    fontSize: 28),
              ),
              SizedBox(
                height: 28,
              ),
              TextField(
                  decoration: InputDecoration(
                      //prefixIcon: Icon(Icons.person),
                      hintText: "User Name",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)))),
              RadioListTile(
                  title: Text(
                    "Laki-Laki",
                    style: TextStyle(fontSize: 15, fontFamily: 'Regular'),
                  ),
                  value: "Laki-Laki",
                  groupValue: gender,
                  onChanged: (value) {
                    setState(() {
                      gender = value.toString();
                    });
                  }),
              RadioListTile(
                  title: Text(
                    "Perempuan",
                    style: TextStyle(fontSize: 15, fontFamily: 'Regular'),
                  ),
                  value: "Perempuan",
                  groupValue: gender,
                  onChanged: (value) {
                    setState(() {
                      gender = value.toString();
                    });
                  }),
              TextField(
                decoration: InputDecoration(
                    //prefixIcon: Icon(Icons.email),
                    hintText: "Email",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10))),
              ),
              SizedBox(
                height: 15,
              ),
              TextField(
                obscuringCharacter: "*",
                obscureText: true,
                decoration: InputDecoration(
                  //prefixIcon: Icon(Icons.password),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  hintText: "Password",
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "By signing up, you agree to our Terms,",
                    style: TextStyle(fontFamily: 'Regular'),
                  ),
                  TextButton(
                      onPressed: () {},
                      child: Text(
                        "Privacy Policy",
                        style: TextStyle(fontFamily: 'Regular'),
                      )),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("and"),
                  TextButton(
                      onPressed: () {},
                      child: Text(
                        "Cookies Policy",
                        style: TextStyle(fontFamily: 'Regular'),
                      ))
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Expanded(
                      child: ElevatedButton(
                          onPressed: () {},
                          child: Text(
                            "Sign Up",
                            style: TextStyle(
                                fontSize: 18,
                                fontFamily: 'Regular',
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ))),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Have an account? clik",
                    style: TextStyle(fontFamily: 'Regular'),
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const login_page()));
                      },
                      child: Text(
                        "Login",
                        style: TextStyle(fontFamily: 'Regular'),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
