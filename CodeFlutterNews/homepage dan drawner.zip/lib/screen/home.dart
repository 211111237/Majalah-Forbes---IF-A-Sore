import 'dart:js_util';

import 'package:flutter/material.dart';
import '../data/data.dart';
import 'package:iniuntukcommit/screen/Tabs/templateKotakBerita2.dart';
import 'Tabs/templateKotakBerita.dart';
import '../widget/drawerWidget.dart';
import '../widget/searchWidget.dart';
import '../widget/tab_dan_trending.dart';

class home extends StatefulWidget {
  final int initialTabIndex;
  const home({super.key, required this.initialTabIndex});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> with TickerProviderStateMixin {
  PageController _pageController = PageController(initialPage: 0);
  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  int _selectedButtomIndex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedButtomIndex = index;
      _pageController.animateToPage(index,
          duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(
        length: 6, vsync: this, initialIndex: widget.initialTabIndex);
    return Scaffold(
      appBar: AppBar(
        title: Align(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "lib/assets/images/logo.png",
            width: 80,
          ),
        ),
      ),
      drawer: drawerWidget(),
      backgroundColor: Color.fromARGB(244, 214, 214, 214),
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _selectedButtomIndex = index;
          });
        },
        children: [
          ListView(
            children: [
              SizedBox(
                height: 20,
              ),
              searchWidget(),
              SizedBox(
                height: 20,
              ),
              Container(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      labelPadding: const EdgeInsets.only(left: 20, right: 20),
                      labelColor: Colors.black,
                      unselectedLabelColor:
                          const Color.fromARGB(255, 98, 98, 98),
                      // indicator: CircleTabIndicator(color: Colors.black, radius: 4),
                      tabs: [
                        Tab(
                          text: 'For You',
                        ),
                        Tab(
                          text: 'Anime',
                        ),
                        Tab(
                          text: 'Teknologi',
                        ),
                        Tab(
                          text: 'Criminal',
                        ),
                        Tab(
                          text: 'Ekonomi',
                        ),
                        Tab(
                          text: 'Followed',
                        ),
                      ]),
                ),
              ),
              Container(
                width: double.maxFinite,
                height: 550,
                child: TabBarView(controller: _tabController, children: [
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 255, 255, 255),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingForYou(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: forYouTab(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 244, 244, 244),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending on Anime",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingAnime(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: animeTab()),
                        ],
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 244, 244, 244),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending on Teknologi",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingTeknologi(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: teknologiTab(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 244, 244, 244),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending on Criminal",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingCriminal(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: criminalTab(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 244, 244, 244),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending on Ekonomi",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingEkonomi(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: ekonomiTab(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Container(
                      color: Color.fromARGB(255, 244, 244, 244),
                      child: Column(
                        children: [
                          Container(
                            color: Color.fromARGB(169, 0, 0, 0),
                            child: Column(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 15, top: 10),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "Trending on Ekonomi",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 150,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        trendingEkonomi(),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: ekonomiTab(),
                          ),
                        ],
                      ),
                    ),
                  ),
                ]),
              ),
            ],
          ),
          Container(
            child: Text("videopage"),
          ),
          Container(
            child: Text("profielpage"),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.play_arrow), label: 'Video'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_sharp), label: 'Profile'),
        ],
        currentIndex: _selectedButtomIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
    );
  }
}
