import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:uas/Screens/forget_pass_screen.dart';
import '../Screens/login_screen.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

enum SingingCharacter { lafayette, jefferson }

class _SignUpState extends State<SignUp> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool? isUsernameEmpty;
  bool? isEmailEmpty;
  bool? isPasswordEmpty;
  bool? isChecked;
  String? _selectedOption;
  @override
  void initState() {
    isUsernameEmpty = false;
    isEmailEmpty = false;
    isPasswordEmpty = false;
    isChecked = false;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 202, 198, 198),
          title: Image.asset(
            "assets/enew.png",
            width: 150,
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(top: 100),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                const Text(
                  'Sign up Your Account',
                  style: TextStyle(
                      fontSize: 35,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: Form(
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            controller: _usernameController,
                            decoration: InputDecoration(
                              labelText: 'User Name',
                              errorText: isUsernameEmpty == true
                                  ? "User name Harus diisi"
                                  : null,
                              hintText: "Masukkan Nama Akun",
                              prefixIcon: Icon(Icons.person),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 18.0),
                          child: Row(
                            children: [
                              for (String option in ["Laki-laki", "Perempuan"])
                                Row(
                                  children: [
                                    Radio<String>(
                                      value: option,
                                      groupValue: _selectedOption,
                                      onChanged: (value) {
                                        setState(() {
                                          _selectedOption = value;
                                        });
                                      },
                                    ),
                                    Text(option),
                                    SizedBox(width: 20),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            controller: _emailController,
                            decoration: InputDecoration(
                              labelText: 'Email',
                              errorText: isEmailEmpty == true
                                  ? "Email Harus diisi"
                                  : null,
                              hintText: "Masukkan Email",
                              prefixIcon: Icon(Icons.email),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: TextField(
                            obscureText: true,
                            controller: _passwordController,
                            keyboardType: TextInputType.visiblePassword,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              errorText: isEmailEmpty == true
                                  ? "Email Harus diisi"
                                  : null,
                              hintText: "Masukkan Password",
                              prefixIcon: Icon(Icons.password),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "By signing up, you agree to our Terms,",
                    style: TextStyle(fontFamily: 'Regular'),
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Login()));
                      },
                      child: Text(
                        "Privacy Policy",
                        style: TextStyle(fontFamily: 'Regular'),
                      )),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("and"),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ForgetPass()));
                      },
                      child: Text(
                        "Cookies Policy",
                        style: TextStyle(fontFamily: 'Regular'),
                      ))
                ],
              ),
              SizedBox(
                height: 20,
              ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: ElevatedButton(
                            onPressed: () {
                              //contoh validasi jika username dan password empy maka akan tampilkan pesan error
                              if (_emailController.text.isEmpty) {
                                setState(() {
                                  isEmailEmpty = true;
                                });
                              }
                              if (_passwordController.text.isEmpty) {
                                setState(() {
                                  isPasswordEmpty = true;
                                });
                              }
                              if (_usernameController.text.isEmpty) {
                                setState(() {
                                  isUsernameEmpty = true;
                                });
                              }
                              if ((_emailController.text.isNotEmpty &&
                                  _passwordController.text.isNotEmpty &&
                                  _usernameController.text.isNotEmpty)) {
                                setState(() {
                                  isUsernameEmpty = false;
                                  isEmailEmpty = false;
                                  isPasswordEmpty = false;
                                });
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return const Login();
                                }));
                              }
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                minimumSize: Size(400, 33)),
                            child: const Text(
                              "Sign up",
                              style:
                                  TextStyle(color: Colors.white, fontSize: 20),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(1),
                          child: Text.rich(
                            TextSpan(
                              children: <InlineSpan>[
                                const TextSpan(text: 'Sudah Punya Akun? Klik'),
                                WidgetSpan(
                                    child: TextButton(
                                  style: TextButton.styleFrom(
                                      textStyle: const TextStyle(fontSize: 14),
                                      padding: EdgeInsets.only(top: 33)),
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const Login()));
                                  },
                                  child: const Text('Login'),
                                )),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
